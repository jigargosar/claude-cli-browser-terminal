# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.8] - 2026-11-04
### Added
- While the comment popup shows, the keys R, Y, N and D press Reply, Yes, No and Done.
- Esc closes the comment popup.
- Each popup button underlines its key letter.

### Changed
- The comment popup shows Reply, Yes, No and Done. Yes, No and Done send their word as the comment.
- Picked text is highlighted in the selection color, so it stands apart from the yellow of commented text.

## 0.1.7 - 2026-10-31
### Added
- Alt+Enter sends the comments, beside Ctrl+Enter.
- Esc in the comment box asks before it discards changed text.
- Every reload or tab close asks first, because comments live only in the page.

### Changed
- The terminal font is Atkinson Hyperlegible Mono at weight 300, with bold at 500. The font ships inside the package.
- Links in a reply show as plain text, so a click can no longer leave the page and lose the comments.

[Unreleased]: https://github.com/jigargosar/claude-cli-browser-terminal/compare/v0.1.8...HEAD
[0.1.8]: https://github.com/jigargosar/claude-cli-browser-terminal/compare/v0.1.7...v0.1.8
